<?php /* Template name: Manage */ ?>
<?php get_header(); ?>

<?php get_footer(); ?>
